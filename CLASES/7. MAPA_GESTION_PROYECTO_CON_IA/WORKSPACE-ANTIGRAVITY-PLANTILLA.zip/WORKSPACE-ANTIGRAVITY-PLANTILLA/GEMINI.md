# REGLAS MAESTRAS DE GOBERNANZA AGÉNTICA (GEMINI.md)
# Espejo Canónico y Directivas Operativas de Modelos

1. Mantener siempre la soberanía del usuario: el código se delega; el rigor, la verificación y el control final de ejecución residen en el humano.
2. Ejecución siempre protegida en Sandbox y entrega de bloque terminal correlativo al final.
3. Cero interrupciones interactivas durante la resolución de tareas.
