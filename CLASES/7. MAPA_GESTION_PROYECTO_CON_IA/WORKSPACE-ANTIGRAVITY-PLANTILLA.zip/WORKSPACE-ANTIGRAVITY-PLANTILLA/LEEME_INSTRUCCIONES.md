# INSTRUCCIONES DE USO DEL WORKSPACE DE ANTIGRAVITY

¡Bienvenido a tu entorno de trabajo profesional con Inteligencia Artificial gobernada!

## Pasos para empezar (en Windows o Mac):
1. Mantén esta carpeta en una ruta limpia y fija:
   - En Windows: `C:\WORKSPACE-ANTIGRAVITY\` o en tu carpeta de usuario.
   - En Mac: `~/WORKSPACE-ANTIGRAVITY/`.
2. Abre Google Antigravity y selecciona **File > Open Folder** (Abrir Carpeta), seleccionando esta carpeta raíz.
3. ¡Listo! Las reglas de gobernanza agéntica (`AGENTS.md`) y la configuración (`settings.json`) ya están activadas.

## Cómo trabajar con la IA:
- Pídele lo que necesites en el chat.
- La IA trabajará en silencio sin abrirte ventanas molestas de "Submit" o "Aprobar".
- Al terminar, te entregará un bloque de código para la terminal. Simplemente abre tu consola (CMD en Windows / Terminal en Mac), pega el bloque y pulsa Enter.
