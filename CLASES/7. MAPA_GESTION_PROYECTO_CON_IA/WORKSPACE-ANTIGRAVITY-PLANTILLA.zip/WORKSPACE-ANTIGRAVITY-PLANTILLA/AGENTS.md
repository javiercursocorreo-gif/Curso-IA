# REGLAS MAESTRAS DE GOBERNANZA AGÉNTICA (AGENTS.md)
# Ecosistema de Trabajo Desatendido en Google Antigravity

## 1. PROTOCOLO DE ORO: CERO-SUBMITS ABSOLUTO
- Prohibición total de ventanas emergentes de aprobación o confirmación interactiva en el editor (`RequestFeedback: false`).
- El agente trabaja de principio a fin de manera desatendida y silenciosa.

## 2. PATRÓN MAESTRO: TRABAJO EN SILENCIO Y COMANDO TERMINAL FINAL
- **Fase 1 (Procesamiento en Sandbox):** Toda lectura, edición y compilación se realiza de forma silenciosa dentro del Sandbox (`BypassSandbox: false`), sin emitir charlas ni popups intermedios.
- **Fase 2 (Entrega de Comando Único):** Al concluir con éxito, el agente entrega un único bloque bash con cabecera y pie visibles mediante `echo` para que el usuario lo copie y pegue en su terminal externa (CMD en Windows / Terminal en Mac).

## 3. ARQUITECTURA ELEPHANT-GOLDFISH (PREVENCIÓN DE DERIVA)
- El agente coordinador mantiene la visión global del proyecto.
- Tareas de auditoría o verificación pesada se delegan en subagentes efímeros limpios que se destruyen inmediatamente tras reportar el resultado (`manage_subagents: kill`).

## 4. PREVENCIÓN DE LAS 4 D DEL CÓDIGO IA
- **Cero Duplicación:** Consultar utilidades existentes antes de reinventar código.
- **Cero Drift:** Respetar los nombres canónicos y la jerarquía de carpetas acordada.
- **Cero Deluge:** Operar con código nativo limpio sin dependencias de terceros innecesarias.
- **Cero Deception:** Autocomprobación previa obligatoria de cada recurso y enlace.
